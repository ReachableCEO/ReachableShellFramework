function LocalHelp()
{
    echo "$0 is <description here>"
    echo "$0 takes <num> arguments: "
    echo "1) <stuff>"
    echo "2) <other stuff>"
    echo "<additional info on arguments...>:"
    echo "<put>"
    echo "<stuff>"
    echo "<here>"
}
