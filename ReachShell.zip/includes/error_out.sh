function error_out()
{
        echo "Bailing out. See above for reason...."
        exit 1
}
